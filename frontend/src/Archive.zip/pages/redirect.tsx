import RedirectProfile from '../components/RedirectProfile'

export default function Redirect() {
  return <RedirectProfile />
}
