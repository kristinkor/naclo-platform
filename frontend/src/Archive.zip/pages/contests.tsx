import React from 'react'

export default function Contests() {
  return <div>Contests page coming soon.</div>
}
