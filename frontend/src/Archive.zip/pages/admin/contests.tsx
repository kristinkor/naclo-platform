import React from 'react'

export default function ContestsPage() {
  return <div>Contests management page coming soon.</div>
}
