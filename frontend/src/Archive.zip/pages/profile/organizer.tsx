import React from 'react'

export default function OrganizerProfile() {
  return <div>Organizer profile page coming soon.</div>
}
